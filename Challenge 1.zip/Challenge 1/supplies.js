// // var selectedOption = document.getElementsByClassName('select').value;
// var userLunch = document.getElementById('user_lunch');
// var node = document.createElement ('li');
// // var newLi = document.createElement('li');
// // var textnode = document.createTextNode

// document.getElementById('add_food').onclick = function(){
//     for (i = 0; i < 5; i++) {
//     var select = document.getElementsByClassName('select')[i].value;
//     node.appendChild(document.createTextNode(select));
//     // console.log(select);
//     // node.appendChild(document.createTextNode(select));
//     // userLunch.appendChild(node);
//     // console.log(select);
//     // node.appendChild(select);
//     // node.appendChild(document.createTextNode(select));
//     // userLunch.appendChild(node);

// 	// var checkbox = document.getElementById('checkbox').checked;
//     // console.log(checkbox);
//     }
//     // node.appendChild(document.createTextNode(select));
//     // userLunch.appendChild(node);
// };

// var userLunch = document.getElementById ('user_lunch');

// function addFoodInLunch (text) {
//     var listItem = document.createElement ('li');
//     listItem.textContent = text;
//     return listItem;
// };

// var list = [
//     userLunch ('lalal');
//     userLunch ('knsdck');
//     userLunch ('jsdnfjk');
// ];

// list.forEach(function (addFoodInLunch) {
//     userLunch.appendChild(addFoodInLunch);
// })

